class Data_Processing {
    //the constructor initializes the the three properties below, which will be usd later on to store processed user data
  constructor() {
      this.raw_user_data = null;
      this.formatted_user_data = null;
      this.cleaned_user_data = null;
  }

  filename = 'Raw_User_Data';

  // This method loads CSV data from file, uses 'fs' module
  load_CSV(filename) {
      const fs = require('fs');
      filename += '.csv';

      const data = fs.readFileSync(filename, 'utf8');
      this.raw_user_data = data;
  }

  format_data() {
    //clears any exisiting formatted user data
    this.formatted_user_data = [];

    // split data by lines
    let rows = this.raw_user_data.split('\n');

    //process each row
    for (let i = 0; i < rows.length; i++) {
        let row = rows[i];
        //skips empty rows
        if (!row.trim()) continue;

        //gets individual data
        const userData = row.split(',');
        const [fullName, dob, age, email] = userData;

        //splits full name into parts
        const nameParts = fullName.split(' ');

        //initialize variables for 
        let title = '';
        let firstName = '';
        let middleName = '';
        let surname = '';

        if (this.isTitle(nameParts[0])) {
            title = nameParts.shift();
        }

        // First name if theres at least one part left
        if (nameParts.length > 0) {
            firstName = nameParts.shift();
        }

        //last is surname if theres any remaining parts
        if (nameParts.length > 0) {
            surname = nameParts.pop();
        }

        // this is miidle name if they are remianing parts
        middleName = nameParts.join(' ');

        // date of birth format is validated
        let dob_parts;
        let DOB;

        if (dob.includes('/')) {
            dob_parts = dob.split('/');
            let [day, month, year] = dob_parts;
            year = parseInt(year);
            if (year < 100) {
                year = year > 4 ? 1900 + year : 2000 + year;
            }
            DOB = `${day.padStart(2, '0')}/${month.padStart(2, '0')}/${year}`;
        } else {
            const [day, month, year] = dob.split(' ');
            DOB = `${day.padStart(2, '0')}/${this.getMonthNumber(month).padStart(2, '0')}/${year.padStart(4, '0')}`;
        }

        // age is parsed
        let parsed_age;
        if (!isNaN(parseFloat(age))) {
            parsed_age = parseFloat(age);
        } else {
            //parse it from words if age is not a number
            parsed_age = this.parsed_age_string(age);
        }

        //email is formatted
        const formattedEmail = email.trim();

        //formatted user data array being added
        this.formatted_user_data.push({
            title: title || '',
            first_name: firstName || '',
            middle_name: middleName || '',
            surname: surname || '',
            date_of_birth: DOB || '',
            age: parsed_age || null,
            email: formattedEmail || ''
        });
    }
}

// this converts age strings written in words into numerical representations
parsed_age_string(ageString) {
    const wordsToNumbers = {
        'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5,
        'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10,
        'eleven': 11, 'twelve': 12, 'thirteen': 13, 'fourteen': 14, 'fifteen': 15,
        'sixteen': 16, 'seventeen': 17, 'eighteen': 18, 'nineteen': 19, 'twenty': 20,
        'thirty': 30, 'forty': 40, 'fifty': 50, 'sixty': 60, 'seventy': 70,
        'eighty': 80, 'ninety': 90, 'hundred': 100, 'thousand': 1000, 'million': 1000000,
    };

    let age = 0;
    ageString.split('-').forEach(part => {
        const words = part.trim().split(' ');
        words.forEach(word => {
            if (wordsToNumbers[word]) {
                age += wordsToNumbers[word];
            }
        });
    });

    return age;
}



// checs titles have formatted correctly
  isTitle(word) {
      const titles = ['Mr', 'Mrs', 'Miss', 'Ms', 'Dr', 'Dr.'];
      return titles.includes(word);
  }

  // converts name of month into numerical representation
  getMonthNumber(month) {
      const monthNames = {
          "January": "01",
          "February": "02",
          "March": "03",
          "April": "04",
          "May": "05",
          "June": "06",
          "July": "07",
          "August": "08",
          "September": "09",
          "October": "10",
          "November": "11",
          "December": "12"
      };
      return monthNames[month];
  }

  clean_data() {
    
    //to avoid modifying the original data
    this.cleaned_user_data = this.formatted_user_data.slice(0,148);

    //repeats over each row of the cleaned data
    for (let i = 0; i < this.cleaned_user_data.length; i++) {
        let row = this.cleaned_user_data[i];

        this.cleanTitle(row);

        this.cleanFirstName(row);

        this.cleanMiddleName(row);

        this.cleanSurname(row);

        this.cleanDob(row);

        this.cleanAge(row);

        //i have tried cleaning the email, but i have been stuck on getting rid of the 1 thats present in every row,
        // so i have made some line of codes that gets rid of the id 1 but in some exceptions 
        this.cleanEmail(row);
        const exceptions = {
            8: 'Mei.Wu1@example.com',
            33: 'Priyanka.Kapoor1@example.com',
            46: 'Priya.Kapoor1@example.com',
            48: 'Alejandro.Garcia1@example.com',
            96: 'Alejandro.Garcia2@example.com',
            109: 'Samuel.Turner1@example.com',
            127: 'Noah.Taylor1@example.com'
        };
        
        if (!(i + 1 in exceptions && row.email === exceptions[i + 1])) {
            row.email = row.email.replace(/[1]/g, '');
        }
        
    }

}


cleanTitle(row) {
  // checks for the title 'Dr.' and removes it if present
  if (row.title === 'Dr.') {
      row.title = 'Dr';
  }
}

// extracts first name from email if theres no first_name present in the row of data
cleanFirstName(row) {
    if (!row.first_name && row.email) {
        const emailParts = row.email.split('@')[0].split('.');
        if (emailParts.length === 2) {
            row.first_name = emailParts[0];
        }
    }
}

cleanMiddleName(row) {
    // no change needed
}

// extracts surname from email if theres no surname present in the row of data
cleanSurname(row) {
    if (!row.surname && row.email) {
        const emailParts = row.email.split('@')[0].split('.');
        if (emailParts.length === 2) {
            row.surname = emailParts[1];
        }
    }
}

cleanDob(row) {
    //no change needed for date of birth
}

cleanAge(row) {
  // verifies age with scpeficied date (26/02/2024) given from assignement 
  const currentDate = new Date('2024-02-26');
  const dob_parts = row.date_of_birth.split('/');
  const dobYear = parseInt(dob_parts[2]);
  const dobMonth = parseInt(dob_parts[1]) - 1;
  const dobDay = parseInt(dob_parts[0]);
  const dob = new Date(dobYear, dobMonth, dobDay);
  let ageFromDob = currentDate.getFullYear() - dob.getFullYear();
  // age is adjusted if birth date has not occurred yet in the current year
  if (currentDate < new Date(currentDate.getFullYear(), dob.getMonth(), dob.getDate())) {
      ageFromDob--;
  }
  row.age = ageFromDob;
}


cleanEmail(row) {
  if (!row.email) {
      //construct email using first name and surname if email blank
      row.email = `${row.first_name}.${row.surname}@example.com`;
  } else if (row.email === '@example.com') {
      //if email is just '@example.com', add first name and surname
      row.email = `${row.first_name}.${row.surname}@example.com`;
  } 
  this.duplicate_emails(row);
}

// ensures each email is unique
duplicate_emails(row) {
  const count = this.count_email_occurences(row.email);
  if (count > 1) {
      let id = 1;
      while (this.email_exists(`${row.first_name}.${row.surname}${id}@example.com`)) {
          id++;
      }
      row.email = `${row.first_name}.${row.surname}${id}@example.com`;
  }
}

// count occurrences of the email in the dataset
count_email_occurences(email) {
  let count = 0;
  for (let i = 0; i < this.formatted_user_data.length; i++) {
      const rowData = this.formatted_user_data[i];
      if (rowData.email === email) {
          count++;
      }
  }
  return count;
}

//checks if the email already exists in the dataset
email_exists(email) {
  for (let i = 0; i < this.formatted_user_data.length; i++) {
      const rowData = this.formatted_user_data[i];
      if (rowData.email === email) {
          return true;
      }
  }
  return false;
}

// finds the most common surname, handles when multiple surnames have same maximum count
  most_common_surname() {
    const counts_surname = {};
    for (let i = 0; i < this.cleaned_user_data.length; i++) {
        const surname = this.cleaned_user_data[i].surname;
        counts_surname[surname] = (counts_surname[surname] || 0) + 1;
    }

    let most_common_surnames = [];
    let max_count = 0;
    for (const surname in counts_surname) {
        if (counts_surname.hasOwnProperty(surname) && counts_surname[surname] >= max_count) {
            if (counts_surname[surname] > max_count) {
                most_common_surnames = []; // Reset array if a new max count is found
                max_count = counts_surname[surname];
            }
            most_common_surnames.push(surname);
        }
    }
    return most_common_surnames;
}


average_age() {
    let total_age = 0;
    let number_of_users = 0;

    //repeats over each user data
    for (let i = 0; i < this.cleaned_user_data.length; i++) {
      const age = this.cleaned_user_data[i].age;
      //checks if age data is availalbe 
      if (!isNaN(age)) {
        total_age += age;
        number_of_users++;
      }
    }

    //avarge age is calculated
    const averageAge = total_age / number_of_users;

    //returns the average age rounded to one decimal place
    return averageAge.toFixed(1);
  }
  youngest_dr() {
    let youngest_dr = null;
    let min_age = Infinity;

    //repeates over each users data
    for (let i = 0; i < this.cleaned_user_data.length; i++) {
      const user = this.cleaned_user_data[i];
      // Checks user has the title "Dr."
      if (user.title === 'Dr') {
        // Checks if user is youngest
        if (user.age < min_age) {
          youngest_dr = user;
          min_age = user.age;
        }
      }
    }

    return youngest_dr;
  }

  most_common_month() {
    const counts_of_month = {};

    //repeats over each user data
    for (let i = 0; i < this.cleaned_user_data.length; i++) {
      const user = this.cleaned_user_data[i];
      //month from date of birth extracted
      const month = user.date_of_birth.split('/')[1];
      //incrememnt count of month
      counts_of_month[month] = (counts_of_month[month] || 0) + 1;
    }

    //find high count month
    let most_common_month = null;
    let max_count = 0;
    for (const month in counts_of_month) {
      if (counts_of_month[month] > max_count) {
        most_common_month = month;
        max_count = counts_of_month[month];
      }
    }

    return most_common_month;
  }

  percentage_titles() {
    const title_counts = {};
  const totalCount = this.cleaned_user_data.length;

  //repeat each user data to count the occurrences of each title
  for (let i = 0; i < totalCount; i++) {
    const user = this.cleaned_user_data[i];
    title_counts[user.title] = (title_counts[user.title] || 0) + 1;
  }

  //order of titles
  const titlesOrder = ['Mr', 'Mrs', 'Miss', 'Ms', 'Dr', ''];

  //calculate percentage of the titles
  const percentageTitles = titlesOrder.map(title => {
    const percentage = Math.round((title_counts[title] || 0) / totalCount * 100);
    return percentage;
  });

  return percentageTitles;
}

percentage_altered() {
    if (!this.formatted_user_data || !this.cleaned_user_data) {
        console.error('Formatted or cleaned user data not available. Please format and clean data first.');
        return null;
    }

    let alteredCount = 0;
    const totalCount = this.formatted_user_data.length;
    const totalProperties = Object.keys(this.formatted_user_data[0]).length;

    //repeqat over each user data to count the altered values
    for (let i = 0; i < totalCount; i++) {
        const formattedUser = this.formatted_user_data[i];
        const cleanedUser = this.cleaned_user_data[i];

        // makes sure that both formattedUser and cleanedUser are valid objects
        if (formattedUser && cleanedUser) {
            // Compare the values of each property and count the differences
            for (const key in formattedUser) {
                if (formattedUser.hasOwnProperty(key) && cleanedUser.hasOwnProperty(key)) {
                    if (formattedUser[key] !== cleanedUser[key]) {
                        alteredCount++;
                    }
                }
            }
        }
    }

    //percentage of altered values based on individual values is calculated
    const percentageAltered = ((alteredCount / (totalCount * totalProperties)) * 100).toFixed(1);
    return parseFloat(percentageAltered);
}


}